﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double numero1, numero2;
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();

        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNumero1.Text, out numero1) &&
               double.TryParse(txtNumero2.Text, out numero2))
            {
                double resultado;
                resultado = numero1 - numero2;
                txtResultado.Text = resultado.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores inválidos");
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNumero1.Text, out numero1) &&
               double.TryParse(txtNumero2.Text, out numero2))
            {
                double resultado;
                resultado = numero1 * numero2;
                txtResultado.Text = resultado.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores inválidos");
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNumero1.Text, out numero1) &&
               double.TryParse(txtNumero2.Text, out numero2))
            {
                if (numero2 != 0)
                {
                    double resultado;
                    resultado = numero1 / numero2;
                    txtResultado.Text = resultado.ToString("N2");
                }
                else
                {
                    MessageBox.Show("Segundo número não pode ser 0");
                }
            }
            else
            {
                MessageBox.Show("Valores inválidos");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNumero1.Text, out numero1) &&
                 Double.TryParse(txtNumero2.Text, out numero2))
            {
                double resultado;
                resultado = numero1 + numero2;
                txtResultado.Text = resultado.ToString("N2");
            }
            else
            {
                MessageBox.Show("Valores inválidos");
            }
        }
    }
}

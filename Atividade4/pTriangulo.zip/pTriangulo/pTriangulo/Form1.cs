﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            double ladoA, ladoB, ladoC;

            if (double.TryParse(txtLadoA.Text, out ladoA) &&
                double.TryParse(txtLadoB.Text, out ladoB) &&
                double.TryParse(txtLadoC.Text, out ladoC))
            {
                if (ladoA < (ladoB + ladoC) && ladoA > Math.Abs(ladoB - ladoC) &&
                    ladoB < (ladoA + ladoC) && ladoB > Math.Abs(ladoA - ladoC) &&
                    ladoC < (ladoA + ladoB) && ladoC > Math.Abs(ladoA - ladoB))
                {
                    VerificaTipoTriangulo(ladoA, ladoB, ladoC);
                }
                else
                {
                    MessageBox.Show("Não é possivel fazer um triangulo com esses valores");
                }
            }
            else
            {
                MessageBox.Show("Valores devem ser numéricos");

            }
        }
        private void VerificaTipoTriangulo(double ladoA, double ladoB, double ladoC)
        {
            if (ladoA == ladoB && ladoB == ladoC)
            {
                MessageBox.Show("Triângulo Equilátero");
            }
            else
            {
                if (ladoA == ladoB || ladoA == ladoC || ladoC == ladoB)
                {
                    MessageBox.Show("Triângulo Isóceles");
                }
                else
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
            }
        }
    }
}

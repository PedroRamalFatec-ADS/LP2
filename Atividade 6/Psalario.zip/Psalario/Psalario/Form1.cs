﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificaDesconto_Click(object sender, EventArgs e)
        {
            lblDados.Visible = true;

            double salLiquido = 0;
            double salBruto = 0;
            double descontoINSS = 0;
            double descontIRPF = 0;
            double SalFamilia = 0;
            double numFilhos = 0;

            if (txtNome.Text == "")
                MessageBox.Show("NOME NÃO PODE SER DEIXADO EM BRANCO");
            else
            {
                if (double.TryParse(mskbxSalBruto.Text, out salBruto) &&
                    double.TryParse(cbxFilhos.Text, out numFilhos))
                {
                    if (salBruto <= 0)
                        MessageBox.Show("Sálario bruto deve ser maior que  0");
                    else
                    { // Calculando o INSS
                        if (salBruto <= 800.47)
                        {
                            txtAliqINSS.Text = "7,65%";
                            descontoINSS = 0.0765 * salBruto;
                        }
                        else if (salBruto <= 1050)
                        {
                            txtAliqINSS.Text = "8,65%";
                            descontoINSS = ((8.65 / 100) * salBruto);
                        }
                        else if (salBruto <= 1400.77)
                        {
                            txtAliqINSS.Text = "9%";
                            descontoINSS = 0.09 * salBruto;
                        }
                        else if (salBruto <= 2801.56)
                        {
                            txtAliqINSS.Text = "11%";
                            descontoINSS = 0.11 * salBruto;
                        }
                        else
                        {
                            txtAliqINSS.Text = "Teto";
                            descontoINSS = 308.17;
                        }

                        txtDescontoINSS.Text = descontoINSS.ToString("N2");

                        // Calculando desconto do imposto de renda

                        if (salBruto <= 1257.12)
                            txtAliqIRPF.Text = "Isento";

                        else if (salBruto <= 2512.08)
                        { 
                            txtAliqIRPF.Text = "15%";
                            descontIRPF = salBruto * 0.15;
                        }
                        else
                        {
                            txtAliqIRPF.Text = "27.5%";
                            descontIRPF = salBruto * 27.5 / 100;
                        }

                        txtDescontoIRPF.Text = descontIRPF.ToString("N2");

                        // calculo salario familia

                        if(numFilhos > 0)
                        {
                            if (salBruto <= 435.52)
                                SalFamilia = 22.33 * numFilhos;
                            else if (salBruto <= 654.61)
                                SalFamilia = 15.74 * numFilhos;
                            else
                                SalFamilia = 0;
                        }

                        txtSalFamilia.Text = SalFamilia.ToString("N2");

                        salLiquido = salBruto - descontoINSS - descontIRPF + SalFamilia;

                        txtSalLiquido.Text = salLiquido.ToString("N2");


                        // mensagem no lblDados 
                        lblDados.Text = "Os descontos do salário " + (rbtnF.Checked ? "da Sra." : "do Sr.") +
                            txtNome.Text + "\n" + " que é " + (ckbxCasado.Checked ? "Casado(a)" : "Solteiro(a)") +
                            "\n" + " e que tem " + Convert.ToString(numFilhos) + " Filho(s) são: ";

                    }
                }
                else
                    MessageBox.Show("Sálario bruto e número de filhos devem ser preenchidos" + "\n" + "E devem ser numéricos");
            }
           
       

          


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtSalFamilia_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAliqIRPF_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAliqINSS_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDescontoIRPF_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSalLiquido_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDescontoINSS_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

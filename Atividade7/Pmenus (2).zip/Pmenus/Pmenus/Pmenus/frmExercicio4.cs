﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCaracNum_Click(object sender, EventArgs e)
        {
            int qtdCaracNum = 0;
            char[] Texto = rchtxtTexto.Text.ToCharArray();

            for (var i = 0; i < rchtxtTexto.Text.Length; i++)
            {
                if (Char.IsNumber(Texto[i]))
                {
                    qtdCaracNum++;
                }
            }
            MessageBox.Show("O Texto contém " + qtdCaracNum.ToString("N0") + " caracteres numéricos");
        }

        private void btnCaracBranc_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int i = 0;
            char[] Texto = rchtxtTexto.Text.ToCharArray();

            while (!Char.IsWhiteSpace(Texto[i]))
            {
                i++;
            }
            posicao = i;

            MessageBox.Show("O primeiro caracter branco está na posição " + posicao.ToString("N0"));
        }

        private void btnCaracAlfa_Click(object sender, EventArgs e)
        {
            int qtdCaracAlfa = 0;
            char[] Texto = rchtxtTexto.Text.ToCharArray();

            foreach (var caracter in Texto)
            {
                if (Char.IsLetter(caracter))
                {
                    qtdCaracAlfa++;
                }
            }
            MessageBox.Show("O Texto contém " + qtdCaracAlfa.ToString("N0") + " caracteres alfabéticos");
        }
    }
}

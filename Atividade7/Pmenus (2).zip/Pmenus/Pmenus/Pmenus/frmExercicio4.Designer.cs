﻿namespace Pmenus
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtTexto = new System.Windows.Forms.RichTextBox();
            this.btnCaracNum = new System.Windows.Forms.Button();
            this.btnCaracBranc = new System.Windows.Forms.Button();
            this.btnCaracAlfa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtTexto
            // 
            this.rchtxtTexto.Location = new System.Drawing.Point(616, 25);
            this.rchtxtTexto.Name = "rchtxtTexto";
            this.rchtxtTexto.Size = new System.Drawing.Size(214, 204);
            this.rchtxtTexto.TabIndex = 0;
            this.rchtxtTexto.Text = "";
            // 
            // btnCaracNum
            // 
            this.btnCaracNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaracNum.Location = new System.Drawing.Point(35, 206);
            this.btnCaracNum.Name = "btnCaracNum";
            this.btnCaracNum.Size = new System.Drawing.Size(145, 92);
            this.btnCaracNum.TabIndex = 1;
            this.btnCaracNum.Text = "Caracter Numéricos";
            this.btnCaracNum.UseVisualStyleBackColor = true;
            this.btnCaracNum.Click += new System.EventHandler(this.btnCaracNum_Click);
            // 
            // btnCaracBranc
            // 
            this.btnCaracBranc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaracBranc.Location = new System.Drawing.Point(209, 206);
            this.btnCaracBranc.Name = "btnCaracBranc";
            this.btnCaracBranc.Size = new System.Drawing.Size(145, 92);
            this.btnCaracBranc.TabIndex = 2;
            this.btnCaracBranc.Text = "1º Caracter Branco";
            this.btnCaracBranc.UseVisualStyleBackColor = true;
            this.btnCaracBranc.Click += new System.EventHandler(this.btnCaracBranc_Click);
            // 
            // btnCaracAlfa
            // 
            this.btnCaracAlfa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaracAlfa.Location = new System.Drawing.Point(397, 206);
            this.btnCaracAlfa.Name = "btnCaracAlfa";
            this.btnCaracAlfa.Size = new System.Drawing.Size(145, 92);
            this.btnCaracAlfa.TabIndex = 3;
            this.btnCaracAlfa.Text = "Caracter Alfabético\r\n";
            this.btnCaracAlfa.UseVisualStyleBackColor = true;
            this.btnCaracAlfa.Click += new System.EventHandler(this.btnCaracAlfa_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1014, 563);
            this.Controls.Add(this.btnCaracAlfa);
            this.Controls.Add(this.btnCaracBranc);
            this.Controls.Add(this.btnCaracNum);
            this.Controls.Add(this.rchtxtTexto);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtTexto;
        private System.Windows.Forms.Button btnCaracNum;
        private System.Windows.Forms.Button btnCaracBranc;
        private System.Windows.Forms.Button btnCaracAlfa;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int num1 = 0;
            int num2 = 0;
            int numSorteado = 0;
            Random sorteio = new Random();

            if (!Int32.TryParse(txtNum1.Text, out num1) &&
                !Int32.TryParse(txtNum2.Text, out num2))
            {
                MessageBox.Show("Números inválidos");
            }

            else
            {
                num2 = Convert.ToInt32(txtNum2.Text);

                if (num1 > num2)
                {
                    numSorteado = sorteio.Next(num2, num1);
                }
                else if (num2 > num1)
                {
                    numSorteado = sorteio.Next(num1, num2);
                }


                MessageBox.Show("Número sorteado: " + numSorteado.ToString());
            }
        }
    }
}

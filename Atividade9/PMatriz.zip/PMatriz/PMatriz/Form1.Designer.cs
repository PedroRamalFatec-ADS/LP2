﻿namespace PMatriz
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbxNomes = new System.Windows.Forms.ListBox();
            this.btnInverter = new System.Windows.Forms.Button();
            this.btnArray = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnMercadorias = new System.Windows.Forms.Button();
            this.btnVariavel = new System.Windows.Forms.Button();
            this.btnNomes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbxNomes
            // 
            this.lbxNomes.FormattingEnabled = true;
            this.lbxNomes.Location = new System.Drawing.Point(508, 12);
            this.lbxNomes.Name = "lbxNomes";
            this.lbxNomes.Size = new System.Drawing.Size(188, 277);
            this.lbxNomes.TabIndex = 0;
            // 
            // btnInverter
            // 
            this.btnInverter.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInverter.Location = new System.Drawing.Point(38, 37);
            this.btnInverter.Name = "btnInverter";
            this.btnInverter.Size = new System.Drawing.Size(130, 69);
            this.btnInverter.TabIndex = 1;
            this.btnInverter.Text = "Ler 20 números e Inverter";
            this.btnInverter.UseVisualStyleBackColor = true;
            this.btnInverter.Click += new System.EventHandler(this.btnInverter_Click);
            // 
            // btnArray
            // 
            this.btnArray.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArray.Location = new System.Drawing.Point(38, 112);
            this.btnArray.Name = "btnArray";
            this.btnArray.Size = new System.Drawing.Size(130, 69);
            this.btnArray.TabIndex = 2;
            this.btnArray.Text = "ArrayList";
            this.btnArray.UseVisualStyleBackColor = true;
            this.btnArray.Click += new System.EventHandler(this.btnArray_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedia.Location = new System.Drawing.Point(38, 199);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(130, 69);
            this.btnMedia.TabIndex = 3;
            this.btnMedia.Text = "Média Alunos";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnMercadorias
            // 
            this.btnMercadorias.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMercadorias.Location = new System.Drawing.Point(212, 37);
            this.btnMercadorias.Name = "btnMercadorias";
            this.btnMercadorias.Size = new System.Drawing.Size(130, 69);
            this.btnMercadorias.TabIndex = 4;
            this.btnMercadorias.Text = "Ler Quant. e Preço Mercadorias";
            this.btnMercadorias.UseVisualStyleBackColor = true;
            this.btnMercadorias.Click += new System.EventHandler(this.btnMercadorias_Click);
            // 
            // btnVariavel
            // 
            this.btnVariavel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVariavel.Location = new System.Drawing.Point(212, 112);
            this.btnVariavel.Name = "btnVariavel";
            this.btnVariavel.Size = new System.Drawing.Size(130, 69);
            this.btnVariavel.TabIndex = 5;
            this.btnVariavel.Text = "Váriavel Total";
            this.btnVariavel.UseVisualStyleBackColor = true;
            this.btnVariavel.Click += new System.EventHandler(this.btnVariavel_Click);
            // 
            // btnNomes
            // 
            this.btnNomes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNomes.Location = new System.Drawing.Point(212, 204);
            this.btnNomes.Name = "btnNomes";
            this.btnNomes.Size = new System.Drawing.Size(141, 64);
            this.btnNomes.TabIndex = 6;
            this.btnNomes.Text = "Nomes Pessoas";
            this.btnNomes.UseVisualStyleBackColor = true;
            this.btnNomes.Click += new System.EventHandler(this.btnNomes_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnNomes);
            this.Controls.Add(this.btnVariavel);
            this.Controls.Add(this.btnMercadorias);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnArray);
            this.Controls.Add(this.btnInverter);
            this.Controls.Add(this.lbxNomes);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lbxNomes;
        private System.Windows.Forms.Button btnInverter;
        private System.Windows.Forms.Button btnArray;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnMercadorias;
        private System.Windows.Forms.Button btnVariavel;
        private System.Windows.Forms.Button btnNomes;
    }
}

